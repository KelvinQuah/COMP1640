<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Management page</title>
    <link rel="stylesheet" href="css\admin manage user page.css">
</head>
<body>
    <div class="app">
        <header class="app-header">
            <div class="app-header-logo">
                <div class="logo">
                    <span class="logo-icon">
                        <img src="path/to/your/logo.png" alt="SEGi Logo">
                    </span>
                    <h1 class="logo-title">
                        <span>SEGi</span>
                        <span>College</span>
                    </h1>
                </div>
            </div>
            <div class="app-header-navigation">
                <div class="tabs">
                    <a href="#">Meeting</a>
                    <a href="admin dashboard.php">Dashboard</a>
                    <a href="admin profile page.php">Profile</a>
                    <a href="admin manage user page.php" class="active">Manage Users</a>
                    <a href="#">Messages</a>
                    <a href="login.php">Log Out</a>
                </div>
            </div>
            <div class="app-header-actions">
                <button class="user-profile">
                    <span>Admin Name</span>
                    <span><img src="https://resilienteducator.com/wp-content/uploads/2012/10/educational-supervisor.jpg" alt="Admin Avatar"></span>
                </button>
                <!-- Add functionality to the admin profile button -->
            </div>
        </header>

        <div class="app-body">
            <div class="dashboard-section">
                <h2>Welcome, Admin Name!</h2>
                <p>This is your personalized profile page where you can view important information at a glance.</p>
            </div>

            <div class="dashboard-section">
                <h2>USER MANAGEMENT</h2>
                <ul>Register new user here!</ul>
                <div class="register__field">
                    <i class="register__icon fas fa-user"></i>
                    <input type="text" class="login__input" placeholder="Role">
                </div>
                <div class="register__field">
                    <i class="register__icon fas fa-user"></i>
                    <input type="text" class="login__input" placeholder="User name">
                </div>
                <div class="register__field">
                    <i class="register__icon fas fa-user"></i>
                    <input type="text" class="login__input" placeholder="Course">
                </div>
                <div class="register__field">
                    <i class="register__icon fas fa-lock"></i>
                    <input type="text" class="login__input" placeholder="Segi id">
                </div>
                <div class="register__field">
                    <i class="register__icon fas fa-lock"></i>
                    <input type="password" class="login__input" placeholder="Password">
                </div>
                <div class="register__field">
                    <i class="register__icon fas fa-lock"></i>
                    <input type="password" class="login__input" placeholder="Personal lecturer/student">
                </div>
            </div>

            <div class="dashboard-section">
                <h2>Recent Activities</h2>
                <!-- Add content for recent admin activities -->
                <ul>
                    <li>Generated User Report - 2024-03-01</li>
                    <li>Managed User Permissions - 2024-02-15</li>
                </ul>
            </div>
        </div>

        <footer class="footer">
            <h1>SEGi College<small>© 2024</small></h1>
            <div>
                SEGi College ©<br>
                All Rights Reserved 2024
            </div>
        </footer>
    </div>
</body>
</html>
