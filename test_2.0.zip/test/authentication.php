<?php
include ('connection.php');
$user_id = $_POST['user_id'];
$password = $_POST['password'];

//to prevent from mysqli injection  
$username = stripcslashes($user_id);
$password = stripcslashes($password);
$username = mysqli_real_escape_string($db_connection, $user_id);
$password = mysqli_real_escape_string($db_connection, $password);

$sql = "SELECT * FROM staff where username = '$user_id' and password = '$password'";
$result = mysqli_query($db_connection, $sql);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$count = mysqli_num_rows($result);

if ($count == 1) {
    echo "<h1><center> Login successful </center></h1>";
} else {
    echo "<h1> Login failed. Invalid username or password.</h1>";
}
?>