<?php
require_once ('config.php');
header('location: login.php');
?>