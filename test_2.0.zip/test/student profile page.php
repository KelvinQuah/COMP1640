<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Profile</title>
    <link rel="stylesheet" href="css/student profile.css">
</head>
<body>
    <div class="app">
        <header class="app-header">
            <div class="app-header-logo">
                <div class="logo">
                    <span class="logo-icon">
                        <img src="path/to/your/logo.png" alt="SEGi Logo">
                    </span>
                    <h1 class="logo-title">
                        <span>SEGi</span>
                        <span>College</span>
                    </h1>
                </div>
            </div>
            <div class="app-header-navigation">
                <div class="tabs">
                    <a href="#">Meeting</a>
                    <a href="student dashboard.php">Dashboard</a>
                    <a href="student profile page.php" class="active">Profile</a>
                    <a href="#">Grades</a>
                    <a href="#">Messages</a>
                    <a href="login.php">Log Out</a>
                </div>
            </div>
            <div class="app-header-actions">
                <button class="user-profile">
                    <span>Jam Son</span>
                    <span><img src="https://assets.codepen.io/285131/almeria-avatar.jpeg" alt="User Avatar"></span>
                </button>
                <!-- Add functionality to the user profile button -->
            </div>
        </header>

        <div class="app-body">
            <div class="dashboard-section">
                <h2>Welcome, Jam Son!</h2>
                <p>This is your personalized profile page where you can view important information at a glance.</p>
            </div>

            <div class="dashboard-section">
                <h2>PROFILE</h2>
                <ul>
                    <li>Name: Jam Son</li>
                    <li>Student Id: SEGi123</li>
                    <li>Course Code: COMP1234</li>
                    <li>Personal Lecturer: Dr. Smith</li>
                </ul>
            </div>

            <div class="dashboard-section">
                <h2>COURSE</h2>
                <table>
                    <tr>
                        <td>Course 1</td>
                        <td>COMP1234</td>
                    </tr>
                    <tr>
                        <td>Course 2</td>
                        <td>COMP2345</td>
                    </tr>
                    <tr>
                        <td>Course 3</td>
                        <td>COMP3456</td>
                    </tr>
                </table>
            </div>
        </div>

        <footer class="footer">
            <h1>SEGi College<small>© 2024</small></h1>
            <div>
                SEGi College ©<br>
                All Rights Reserved 2024
            </div>
        </footer>
    </div>
</body>
</html>
