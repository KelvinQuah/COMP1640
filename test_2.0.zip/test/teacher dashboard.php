<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="css/teacher dashboard.css">
</head>
<body>
    <div class="app">
        <header class="app-header">
            <div class="app-header-logo">
                <div class="logo">
                    <span class="logo-icon">
                        <img src="path/to/your/logo.png" alt="SEGi College Logo">
                    </span>
                    <h1 class="logo-title">
                        <span>SEGi</span>
                        <span>College</span>
                    </h1>
                </div>
            </div>
            <div class="app-header-navigation">
                <nav class="tabs">
                    <a href="#">Meeting</a>
                    <a href="teacher dashboard.php" class="active">Dashboard</a>
                    <a href="teacher profile page.php">Profile</a>
                    <a href="#">My Classes</a>
                    <a href="#">Grades</a>
                    <a href="#">Messages</a>
                    <a href="login.php">Log Out</a>
                </nav>
            </div>
            <div class="app-header-actions">
                <button class="user-profile">
                    <span>John Doe</span>
                    <span><img src="https://thumbs.dreamstime.com/b/attractive-buisnessman-teacher-glasses-business-office-concept-34602289.jpg" alt="Teacher Avatar"></span>
                </button>
                <!-- Add functionality to the user profile button -->
            </div>
        </header>

        <div class="app-body">
            <div class="dashboard-section">
                <h2>Welcome, John Doe!</h2>
                <p>This is your personalized teacher dashboard where you can manage your classes and view important information.</p>
            </div>

            <div class="dashboard-section">
                <h2>Upcoming Events</h2>
                <ul>
                    <li>Event 1</li>
                    <li>Event 2</li>
                    <li>Event 3</li>
                </ul>
            </div>

            <div class="dashboard-section">
                <h2>Latest Events</h2>
                <table>
                    <tr>
                        <td>Event 1</td>
                        <td>Happy Chinese New Year</td>
                    </tr>
                    <tr>
                        <td>Event 2</td>
                        <td>Lion Dance Event</td>
                    </tr>
                </table>
            </div>
        </div>

        <footer class="footer">
            <h1>SEGi College<small>© 2024</small></h1>
            <div>
                SEGi College ©<br>
                All Rights Reserved 2024
            </div>
        </footer>
    </div>
</body>
</html>
