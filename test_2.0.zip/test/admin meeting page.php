<!DOCTYPE html>
<html>
<head>
    <title>Meeting Scheduler</title>
    <link rel="stylesheet" href="css/admin meeting page.css">
</head>
<body>

<h2>Schedule a Meeting</h2>

<?php
// Define database connection variables
$servername = "localhost"; // Change this to your MySQL server name
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$dbname = "your_database_name"; // Change this to your database name

// Initialize variables to hold form data and error messages
$name = $date = $time = "";
$nameErr = $dateErr = $timeErr = "";

// Function to sanitize input data
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input fields
    if (empty($_POST["name"])) {
        $nameErr = "Name is required";
    } else {
        $name = test_input($_POST["name"]);
    }

    if (empty($_POST["date"])) {
        $dateErr = "Date is required";
    } else {
        $date = test_input($_POST["date"]);
    }

    if (empty($_POST["time"])) {
        $timeErr = "Time is required";
    } else {
        $time = test_input($_POST["time"]);
    }

    // If no errors, proceed to insert data into database
    if (empty($nameErr) && empty($dateErr) && empty($timeErr)) {
        try {
            // Create a PDO connection to the database
            $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            // Set PDO error mode to exception
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Prepare SQL statement to insert data into the database
            $stmt = $pdo->prepare("INSERT INTO meetings (name, meeting_date, meeting_time) VALUES (:name, :date, :time)");
            // Bind parameters and execute the statement
            $stmt->execute(['name' => $name, 'date' => $date, 'time' => $time]);

            // Display success message
            echo "<p>Meeting scheduled successfully!</p>";

            // Clear form inputs
            $name = $date = $time = "";

        } catch (PDOException $e) {
            // Display error message if database operation fails
            echo "Error: " . $e->getMessage();
        }
    }
}
?>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    Name: <input type="text" name="name" value="<?php echo $name;?>">
    <span style="color: red;"><?php echo $nameErr;?></span>
    <br><br>
    Date: <input type="date" name="date" value="<?php echo $date;?>">
    <span style="color: red;"><?php echo $dateErr;?></span>
    <br><br>
    Time: <input type="time" name="time" value="<?php echo $time;?>">
    <span style="color: red;"><?php echo $timeErr;?></span>
    <br><br>
    <input type="submit" name="submit" value="Schedule Meeting">
</form>

</body>
</html>
