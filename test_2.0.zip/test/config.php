<?php
// Database configuration
$servername = "localhost";
$username = "titanic";
$password = "titanic";

try {
    $pdo = new PDO("mysql:host=$servername", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sqlFile = 'database.sql';
    if (file_exists($sqlFile)) {
        $sqlCommands = file_get_contents($sqlFile);
        $pdo->exec($sqlCommands);
        echo "Database initialized successfully!";
    } else {
        echo "Error: SQL file not found.!\n";
    }
    echo "<br>";
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>