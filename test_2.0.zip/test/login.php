<html>

<head>
    <title>E Tutor System</title>
    <link rel="stylesheet" type="text/css" href="login.css" />
</head>

<body>
    <div class="container">
        <div class="screen">
            <div class="screen_content">
                <form name="login" action="authentication.php" onsubmit="return validation()" method="POST">
                    <div class="login_field">
                        <i class="login_icon fas fa-user"></i>
                        <input type="text" id="user_id" name="user_id" class="login_input" placeholder="User ID: "
                            required>
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-lock"></i>
                        <input type="password" id="password" name="password" class="login_input"
                            placeholder="Password: " required>
                    </div>
                    <div class="login__field">
                        <i class="login__icon fas fa-users"></i>
                    </div>
                    <button type="submit" class="button login_submit">Log In Now</button>
                </form>
            </div>
            <div class="screen_background">
                <span class="screen_background_shape screen_background_shape4"></span>
                <span class="screen_background_shape screen_background_shape3"></span>
                <span class="screen_background_shape screen_background_shape2"></span>
                <span class="screen_background_shape screen_background_shape1"></span>
            </div>
        </div>
    </div>
    <script>
        function validation() {
            var id = document.f1.user_id.value;
            var ps = document.f1.password.value;
            if (id.length == "" && ps.length == "") {
                alert("User Name and Password fields are empty");
                return false;
            } else {
                if (id.length == "") {
                    alert("User Name is empty");
                    return false;
                }
                if (ps.length == "") {
                    alert("Password field is empty");
                    return false;
                }
            }
        }
    </script>
</body>

</html>