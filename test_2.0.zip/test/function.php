<?php

function generateStudentID($intake) {
    global $pdo;

    try {
        // Retrieve the current year and next student number
        $stmt = $pdo->query("SELECT current_year, next_student_number FROM student_id_counter FOR UPDATE");
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $currentYear = $row['current_year'];
        $nextStudentNumber = $row['next_student_number'];

        // Format the student ID with the current year and leading zeros for the number
        $studentID = 'STUD' . substr($currentYear, -2) . str_pad($nextStudentNumber, 4, '0', STR_PAD_LEFT);

        // Update the student_id_counter for the next student
        $newNextStudentNumber = $nextStudentNumber + 1;
        $pdo->exec("UPDATE student_id_counter SET next_student_number = $newNextStudentNumber");

        // Insert new student record into the student table
        $stmt = $pdo->prepare("INSERT INTO student (student_id, intake) VALUES (?, ?)");
        $stmt->execute([$studentID, $intake]);

        return $studentID;
    } catch (PDOException $e) {
        // Handle database errors
        die("Error generating student ID: " . $e->getMessage());
    }
}

?>