<!DOCTYPE html>
<html>
<head>
    <title>Meeting Scheduler</title>
    <link rel="stylesheet" href="css\admin meeting page.css">
</head>
<body>

<h2>Schedule a Meeting</h2>

<?php
// Define variables and initialize with empty values
$name = $email = $date = $time = $message = "";
$nameErr = $emailErr = $dateErr = $timeErr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (empty($_POST["name"])) {
        $nameErr = "Name is required";
    } else {
        $name = test_input($_POST["name"]);
    }

    // Validate email
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        }
    }

    // Validate date
    if (empty($_POST["date"])) {
        $dateErr = "Date is required";
    } else {
        $date = test_input($_POST["date"]);
    }

    // Validate time
    if (empty($_POST["time"])) {
        $timeErr = "Time is required";
    } else {
        $time = test_input($_POST["time"]);
    }

    // Optional: Additional validation and processing (e.g., save to database, send email, etc.)
    if (empty($nameErr) && empty($emailErr) && empty($dateErr) && empty($timeErr)) {
        // Here you can process the data, e.g., save to database
        // Example: You may use PDO to insert data into a database

        // Display success message
        echo "<p>Meeting scheduled successfully!</p>";

        // Clear form inputs
        $name = $email = $date = $time = "";
    }
}

// Helper function to sanitize input data
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    Name: <input type="text" name="name" value="<?php echo $name;?>">
    <span style="color: red;"><?php echo $nameErr;?></span>
    <br><br>
    Email: <input type="text" name="email" value="<?php echo $email;?>">
    <span style="color: red;"><?php echo $emailErr;?></span>
    <br><br>
    Date: <input type="date" name="date" value="<?php echo $date;?>">
    <span style="color: red;"><?php echo $dateErr;?></span>
    <br><br>
    Time: <input type="time" name="time" value="<?php echo $time;?>">
    <span style="color: red;"><?php echo $timeErr;?></span>
    <br><br>
    <input type="submit" name="submit" value="Schedule Meeting">
</form>

</body>
</html>
