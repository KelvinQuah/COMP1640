<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="css/student dashboard.css">
</head>
<body>
    <div class="app">
        <header class="app-header">
            <div class="app-header-logo">
                <div class="logo">
                    <span class="logo-icon">
                        <img src="path/to/your/logo.png" alt="SEGi Logo">
                    </span>
                    <h1 class="logo-title">
                        <span>SEGi</span>
                        <span>College</span>
                    </h1>
                </div>
            </div>
            <div class="app-header-navigation">
                <div class="tabs">
                    <a href="#">Meeting</a>
                    <a href="student dashboard.php" class="active">Dashboard</a>
                    <a href="student profile page.php">Profile</a>
                    <a href="#">Grades</a>
                    <a href="#">Messages</a>
                    <a href="login.php">Log Out</a>
                </div>
            </div>
            <div class="app-header-actions">
                <button class="user-profile">
                    <span>Jam Son</span>
                    <span><img src="https://assets.codepen.io/285131/almeria-avatar.jpeg" alt="User Avatar"></span>
                </button>
                <!-- Add functionality to the user profile button -->
            </div>
        </header>

        <div class="app-body">
            <div class="dashboard-section">
                <h2>Welcome, Jam Son!</h2>
                <!-- Add content for the dashboard section -->
                <p>This is your personalized dashboard where you can view important information at a glance.</p>
            </div>

            <div class="dashboard-section">
                <h2>Upcoming Events</h2>
                <!-- Add content for upcoming events -->
                <ul>
                    <li>Event 1</li>
                    <li>Event 2</li>
                    <li>Event 3</li>
                </ul>
            </div>

            <div class="dashboard-section">
                <h2>Latest Events</h2>
                <!-- Add content for latest events -->
                <table>
                    <tr>
                        <td>Event 1</td>
                        <td>Happy Chinese New Year</td>
                    </tr>
                    <tr>
                        <td>Event 2</td>
                        <td>Lion Dance Event</td>
                    </tr>
                </table>
            </div>
        </div>

        <footer class="footer">
            <h1>SEGi College<small>© 2024</small></h1>
            <div>
                SEGi College ©<br>
                All Rights Reserved 2024
            </div>
        </footer>
    </div>
</body>
</html>
