<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Profile</title>
    <link rel="stylesheet" href="css\admin profile.css">
</head>
<body>
    <div class="app">
        <header class="app-header">
            <div class="app-header-logo">
                <div class="logo">
                    <span class="logo-icon">
                        <img src="path/to/your/logo.png" alt="SEGi Logo">
                    </span>
                    <h1 class="logo-title">
                        <span>SEGi</span>
                        <span>College</span>
                    </h1>
                </div>
            </div>
            <div class="app-header-navigation">
                <div class="tabs">
                    <a href="#">Meeting</a>
                    <a href="admin dashboard.php">Dashboard</a>
                    <a href="admin profile page.php" class="active">Profile</a>
                    <a href="admin manage user page.php">Manage Users</a>
                    <a href="#">Messages</a>
                    <a href="login.php">Log Out</a>
                </div>
            </div>
            <div class="app-header-actions">
                <button class="user-profile">
                    <span>Admin Name</span>
                    <span><img src="https://resilienteducator.com/wp-content/uploads/2012/10/educational-supervisor.jpg" alt="Admin Avatar"></span>
                </button>
                <!-- Add functionality to the admin profile button -->
            </div>
        </header>

        <div class="app-body">
            <div class="dashboard-section">
                <h2>Welcome, Admin Name!</h2>
                <p>This is your personalized profile page where you can view important information at a glance.</p>
            </div>

            <div class="dashboard-section">
                <h2>PROFILE</h2>
                <ul>
                    <li>Name: Admin Name</li>
                    <li>Employee Id: A12345</li>
                    <li>Department: Administration</li>
                    <li>Responsibilities: User Management, Report Generation</li>
                </ul>
            </div>

            <div class="dashboard-section">
                <h2>Recent Activities</h2>
                <ul>
                    <li>Generated User Report - 2024-03-01</li>
                    <li>Managed User Permissions - 2024-02-15</li>
                </ul>
            </div>
        </div>

        <footer class="footer">
            <h1>SEGi College<small>© 2024</small></h1>
            <div>
                SEGi College ©<br>
                All Rights Reserved 2024
            </div>
        </footer>
    </div>
</body>
</html>
