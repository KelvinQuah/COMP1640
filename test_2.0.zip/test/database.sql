DROP DATABASE IF EXISTS etutor;
CREATE DATABASE etutor;
USE etutor;

DROP TABLE IF EXISTS interactions;
DROP TABLE IF EXISTS documents;
DROP TABLE IF EXISTS meetings;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS tutor;
DROP TABLE IF EXISTS student;
DROP TABLE IF EXISTS users;

DROP TABLE IF EXISTS staff;

-- Create the staff table (assuming staff are separate from users)
CREATE TABLE
    staff (
        staff_id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        staff_name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL
    );

CREATE TABLE
    users (
        user_id VARCHAR(10) PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        role ENUM ('student', 'tutor') NOT NULL,
        UNIQUE KEY (username)
    );

CREATE TABLE
    tutor (
        tutor_id VARCHAR(10) PRIMARY KEY,
        tutor_name VARCHAR(255) NOT NULL,
        status ENUM ('active', 'inactive', 'on_leave') NOT NULL,
        FOREIGN KEY (tutor_id) REFERENCES users (user_id)
    );

CREATE TABLE
    student (
        student_id VARCHAR(10) PRIMARY KEY,
        student_name VARCHAR(255) NOT NULL,
        intake VARCHAR(10) NOT NULL,
        course VARCHAR(255) NOT NULL,
        program VARCHAR(255) NOT NULL,
        tutor_id VARCHAR(10) NOT NULL,
        FOREIGN KEY (student_id) REFERENCES users (user_id),
        FOREIGN KEY (tutor_id) REFERENCES users (user_id)
    );

CREATE TABLE
    messages (
        message_id INT AUTO_INCREMENT PRIMARY KEY,
        sender_id VARCHAR(10) NOT NULL,
        receiver_id VARCHAR(10) NOT NULL,
        message_text TEXT NOT NULL,
        sent_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (sender_id) REFERENCES users (user_id),
        FOREIGN KEY (receiver_id) REFERENCES users (user_id)
    );

CREATE TABLE
    meetings (
        meeting_id INT AUTO_INCREMENT PRIMARY KEY,
        student_id VARCHAR(10) NOT NULL,
        tutor_id VARCHAR(10) NOT NULL,
        meeting_date DATETIME NOT NULL,
        meeting_notes TEXT,
        FOREIGN KEY (student_id) REFERENCES student (student_id),
        FOREIGN KEY (tutor_id) REFERENCES tutor (tutor_id)
    );

CREATE TABLE
    documents (
        document_id INT AUTO_INCREMENT PRIMARY KEY,
        document_name VARCHAR(255) NOT NULL,
        uploaded_by VARCHAR(10) NOT NULL,
        upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        file_path VARCHAR(255) NOT NULL,
        comments TEXT,
        FOREIGN KEY (uploaded_by) REFERENCES users (user_id)
    );

CREATE TABLE
    interactions (
        interaction_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(10) NOT NULL,
        interaction_type ENUM ('message', 'meeting', 'document_upload') NOT NULL,
        interaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        interaction_details TEXT,
        FOREIGN KEY (user_id) REFERENCES users (user_id)
    );

INSERT INTO
    staff (username, password, email)
VALUES
    ('admin1', 'admin1', 'admin1@gmail.com'),
    ('admin2', 'admin2', 'admin2@gmail.com'),
    ('admin3', 'admin3', 'admin3@gmail.com');

INSERT INTO
    users (user_id, username, password, email, role)
VALUES
    ('STUD240001', 'student1', 'student1', 'student1@gmail.com', 'student'),
    ('STUD240002', 'student2', 'student2', 'student2@gmail.com', 'student'),
    ('STUD240003', 'student3', 'student3', 'student3@gmail.com', 'student'),
    ('TUTO750001', 'tutor1', 'tutor1', 'tutor1@hotmail.com', 'tutor'),
    ('TUTO800002', 'tutor2', 'tutor2', 'tutor2@hotmail.com', 'tutor'),
    ('TUTO850003', 'tutor3', 'tutor3', 'tutor3@hotmail.com', 'tutor');

INSERT INTO
    tutor (tutor_id, tutor_name, status)
VALUES
    ('TUTO750001', 'Mr. David Williams', 'active'),
    ('TUTO800002', 'Dr. Emily Johnson', 'on_leave'),
    ('TUTO850003', 'Prof. Michael Brown', 'inactive');

INSERT INTO
    student (student_id, student_name, intake, course, program, tutor_id)
VALUES
    ('STUD240001', 'John Doe', 'JAN 2024', 'Mathematics', 'Bachelor in Computing', 'TUTO750001'),
    ('STUD240002', 'Jane Smith', 'FEB 2024', 'Physics', 'Bachelor in Science', 'TUTO800002'),
    ('STUD240003', 'Mike Johnson', 'MAR 2024', 'Chemistry', 'Diploma in Chemistry', 'TUTO850003');

INSERT INTO
    messages (sender_id, receiver_id, message_text)
VALUES
    ('STUD240001', 'TUTO750001', 'Hello Mr. David Williams, I need help with the assignment.'),
    ('TUTO750001', 'STUD240001', 'Sure, I can assist you. Let''s schedule a meeting.'),
    ('STUD240002', 'TUTO800002', 'Hi Dr. Emily Johnson, I have a question about the course material.'),
    ('TUTO800002', 'STUD240002', 'Of course! Feel free to ask me anything.'),
    ('STUD240003', 'TUTO850003', 'Hello Prof. Michael Brown, Can we discuss my project progress?'),
    ('TUTO850003', 'STUD240003', 'Certainly! Let''s arrange a virtual meeting.');

INSERT INTO
    meetings (student_id, tutor_id, meeting_date, meeting_notes)
VALUES
    ('STUD240001', 'TUTO750001', '2024-05-10 15:00:00', 'Discuss assignment details'),
    ('STUD240002', 'TUTO800002', '2024-05-12 14:30:00', 'Review course topics'),
    ('STUD240003', 'TUTO850003', '2024-05-14 10:00:00', 'Project progress review');

INSERT INTO
    documents (document_name, uploaded_by, file_path, comments)
VALUES
    ('Assignment Details', 'STUD240001', '/uploads/assignment_details.pdf', 'Please review and provide feedback.'),
    ('Course Material', 'STUD240002', '/uploads/course_material.docx', 'Important notes for the upcoming exam.'),
    ('Project Proposal', 'STUD240003', '/uploads/project_proposal.pdf', 'Final version for submission');

INSERT INTO
    interactions (user_id, interaction_type, interaction_details)
VALUES
    ('STUD240001', 'message', 'Sent message to Mr. David Williams requesting assistance with assignment'),
    ('TUTO750001', 'meeting', 'Scheduled virtual meeting with Student1 to discuss assignment'),
    ('STUD240002', 'message', 'Asked Dr. Emily Johnson about course material'),
    ('TUTO800002', 'message', 'Responded to Student2''s inquiry about course material'),
    ('STUD240003', 'message', 'Requested meeting with Prof. Michael Brown to discuss project progress'),
    ('TUTO850003', 'meeting', 'Confirmed virtual meeting with Student3 to review project progress');