<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css\admin dashboard.css">
</head>
<body>
    <div class="app">
        <header class="app-header">
            <div class="app-header-logo">
                <div class="logo">
                    <span class="logo-icon">
                        <img src="path/to/your/logo.png" alt="SEGi College Logo">
                    </span>
                    <h1 class="logo-title">
                        <span>SEGi</span>
                        <span>College</span>
                    </h1>
                </div>
            </div>
            <div class="app-header-navigation">
                <nav class="tabs">
                    <a href="admin meeting page.php">Meeting</a>
                    <a href="admin dashboard.php" class="active">Dashboard</a>
                    <a href="admin profile page.php">Profile</a>
                    <a href="admin manage user page.php">Manage Users</a>
                    <a href="#">Messages</a>
                    <a href="login.php">Log Out</a>
                </nav>
            </div>
            <div class="app-header-actions">
                <button class="user-profile">
                    <span>Admin Name</span>
                    <span><img src="https://resilienteducator.com/wp-content/uploads/2012/10/educational-supervisor.jpg" alt="Admin Avatar"></span>
                </button>
                <!-- Add functionality to the admin profile button -->
            </div>
        </header>

        <div class="app-body">
            <div class="dashboard-section">
                <h2>Welcome, Admin Name!</h2>
                <!-- Add content for the admin dashboard section -->
                <p>This is your admin dashboard where you can manage users, generate reports, and access other administrative features.</p>
            </div>

            <div class="dashboard-section">
                <h2>Upcoming Events</h2>
                <!-- Add content for upcoming events -->
                <ul>
                    <li>Event 1</li>
                    <li>Event 2</li>
                    <li>Event 3</li>
                </ul>
            </div>

            <div class="dashboard-section">
                <h2>Latest Events</h2>
                <!-- Add content for latest events -->
                <table>
                    <tr>
                        <td>Event 1</td>
                        <td>Happy Chinese New Year</td>
                    </tr>
                    <tr>
                        <td>Event 2</td>
                        <td>Lion Dance Event</td>
                    </tr>
                </table>
            </div>
        </div>

        <footer class="footer">
            <h1>SEGi College<small>© 2024</small></h1>
            <div>
                SEGi College ©<br>
                All Rights Reserved 2024
            </div>
        </footer>
    </div>
</body>
</html>
