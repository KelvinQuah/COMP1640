<!DOCTYPE html>
<html>
<head>
    <title>Contact Us</title>
</head>
<body>

<h2>Contact Us</h2>

<?php
// Define variables and initialize with empty values
$name = $email = $message = "";
$nameErr = $emailErr = $messageErr = "";
$successMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (empty($_POST["name"])) {
        $nameErr = "Name is required";
    } else {
        $name = test_input($_POST["name"]);
    }

    // Validate email
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = test_input($_POST["email"]);
        // Check if email address is well-formed
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        }
    }

    // Validate message
    if (empty($_POST["message"])) {
        $messageErr = "Message is required";
    } else {
        $message = test_input($_POST["message"]);
    }

    // If all inputs are valid, proceed to send the message
    if (empty($nameErr) && empty($emailErr) && empty($messageErr)) {
        // Email settings
        $to = "recipient@example.com";  // Change this to your recipient email address
        $subject = "New Message from $name";
        $body = "Name: $name\n";
        $body .= "Email: $email\n\n";
        $body .= "Message:\n$message";

        // Send email
        $headers = "From: $email\r\n";
        $headers .= "Reply-To: $email\r\n";

        if (mail($to, $subject, $body, $headers)) {
            // Email sent successfully
            $successMessage = "Message sent successfully!";
            // Clear form inputs
            $name = $email = $message = "";
        } else {
            // Email sending failed
            $errorMessage = "Oops! Something went wrong and we couldn't send your message. Please try again later.";
        }
    }
}

// Helper function to sanitize input data
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    Name: <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>">
    <span style="color: red;"><?php echo $nameErr; ?></span>
    <br><br>
    Email: <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
    <span style="color: red;"><?php echo $emailErr; ?></span>
    <br><br>
    Message: <textarea name="message" rows="4"><?php echo htmlspecialchars($message); ?></textarea>
    <span style="color: red;"><?php echo $messageErr; ?></span>
    <br><br>
    <input type="submit" name="submit" value="Send Message">
</form>

<?php
// Display success or error message
if (!empty($successMessage)) {
    echo "<p style='color: green;'>$successMessage</p>";
} elseif (!empty($errorMessage)) {
    echo "<p style='color: red;'>$errorMessage</p>";
}
?>

</body>
</html>
