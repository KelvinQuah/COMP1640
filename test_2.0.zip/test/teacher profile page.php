<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher Profile</title>
    <link rel="stylesheet" href="css/teacher profile.css">
</head>
<body>
<div class="app">
    <header class="app-header">
        <div class="app-header-logo">
            <div class="logo">
                <span class="logo-icon">
                    <img src="path/to/your/logo.png" alt="SEGi Logo">
                </span>
                <h1 class="logo-title">
                    <span>SEGi</span>
                    <span>College</span>
                </h1>
            </div>
        </div>
        <div class="app-header-navigation">
            <div class="tabs">
                <a href="#">Meeting</a>
                <a href="teacher dashboard.php">Dashboard</a>
                <a href="teacher profile page.php" class="active">Profile</a>
                <a href="#">My Classes</a>
                <a href="#">Grades</a>
                <a href="#">Messages</a>
                <a href="login.php">Log Out</a>
            </div>
        </div>
        <div class="app-header-actions">
            <button class="user-profile">
                <span>John Doe</span>
                <span><img src="https://thumbs.dreamstime.com/b/attractive-buisnessman-teacher-glasses-business-office-concept-34602289.jpg" alt="Teacher Avatar"></span>
            </button>
            <!-- Add functionality to the teacher profile button -->
        </div>
    </header>

    <div class="app-body">
        <div class="dashboard-section">
            <h2>Welcome, John Doe!</h2>
            <p>This is your personalized profile page where you can view important information at a glance.</p>
        </div>

        <div class="dashboard-section">
            <h2>PROFILE</h2>
            <ul>
                <li>Name: John Doe</li>
                <li>Employee Id: T12345</li>
                <li>Department: Computer Science</li>
                <li>Teaching Subjects: COMP101, COMP202, MATH301</li>
            </ul>
        </div>

        <div class="dashboard-section">
            <h2>Classes and Schedule</h2>
            <ul>
                <li>Class 1 - Monday, 9:00 AM</li>
                <li>Class 2 - Wednesday, 2:00 PM</li>
                <li>Class 3 - Friday, 11:00 AM</li>
            </ul>
        </div>
    </div>

    <footer class="footer">
        <h1>SEGi College<small>© 2024</small></h1>
        <div>
            SEGi College ©<br>
            All Rights Reserved 2024
        </div>
    </footer>
</div>
</body>
</html>
